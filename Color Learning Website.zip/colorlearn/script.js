// ColorLearn - Interactive Color Theory Website

// Emotion data
const emotions = [
  {
    color: '#EF4444',
    name: 'Red',
    description: 'The most emotionally intense color. Red stimulates a faster heartbeat and breathing.',
    emotions: ['Passion', 'Energy', 'Urgency', 'Love', 'Anger'],
    uses: ['Call-to-action buttons', 'Sale promotions', 'Food branding', 'Warning signs'],
    icon: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>'
  },
  {
    color: '#3B82F6',
    name: 'Blue',
    description: 'The color of the sky and sea. Blue causes the body to produce calming chemicals.',
    emotions: ['Trust', 'Calm', 'Stability', 'Sadness', 'Professionalism'],
    uses: ['Corporate branding', 'Healthcare', 'Technology', 'Financial services'],
    icon: '<path d="M17.5 19c0-1.7-1.3-3-3-3h-2c-1.7 0-3 1.3-3 3M12 3v10M8 7h8"/>'
  },
  {
    color: '#EAB308',
    name: 'Yellow',
    description: 'The color of sunshine. Yellow produces a warming effect and stimulates mental activity.',
    emotions: ['Joy', 'Optimism', 'Energy', 'Caution', 'Warmth'],
    uses: ['Children\'s products', 'Creative industries', 'Warning labels', 'Food packaging'],
    icon: '<circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>'
  },
  {
    color: '#22C55E',
    name: 'Green',
    description: 'The color of nature. Green is the easiest color on the eyes and has healing power.',
    emotions: ['Growth', 'Harmony', 'Freshness', 'Safety', 'Envy'],
    uses: ['Environmental causes', 'Organic products', 'Health & wellness', 'Financial growth'],
    icon: '<path d="M7 20h10M10 20c5.5-2.5.8-6.4 3-10"/>'
  },
  {
    color: '#A855F7',
    name: 'Purple',
    description: 'Combines the stability of blue and the energy of red. Associated with royalty and luxury.',
    emotions: ['Luxury', 'Creativity', 'Mystery', 'Royalty', 'Spirituality'],
    uses: ['Beauty products', 'Premium brands', 'Creative services', 'Spiritual content'],
    icon: '<path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3z"/>'
  },
  {
    color: '#F97316',
    name: 'Orange',
    description: 'Combines the energy of red and the happiness of yellow. Represents enthusiasm.',
    emotions: ['Enthusiasm', 'Creativity', 'Warmth', 'Success', 'Encouragement'],
    uses: ['Sports brands', 'Call-to-actions', 'Youth marketing', 'Food & beverage'],
    icon: '<path d="M12 3c4.97 0 9 4.03 9 9s-4.03 9-9 9c-1.76 0-3.4-.51-4.79-1.38C8.46 17.84 10 15.5 10 13c0-2.5-1.54-4.84-3.79-6.62C7.6 5.51 9.24 5 11 5"/>'
  },
  {
    color: '#06B6D4',
    name: 'Cyan',
    description: 'A refreshing color that evokes feelings of cleanliness and modern technology.',
    emotions: ['Clarity', 'Refreshment', 'Youth', 'Technology', 'Cleanliness'],
    uses: ['Tech startups', 'Clean products', 'Water-related brands', 'Modern design'],
    icon: '<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>'
  },
  {
    color: '#EC4899',
    name: 'Pink',
    description: 'A calming color that represents compassion and nurturing. Associated with love.',
    emotions: ['Romance', 'Compassion', 'Playfulness', 'Femininity', 'Sweetness'],
    uses: ['Beauty & fashion', 'Charitable causes', 'Baby products', 'Romantic themes'],
    icon: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>'
  }
];

// Color mixes data
const colorMixes = [
  { name1: 'Red', color1: '#EF4444', name2: 'Yellow', color2: '#EAB308', resultName: 'Orange', resultColor: '#F97316' },
  { name1: 'Yellow', color1: '#EAB308', name2: 'Blue', color2: '#3B82F6', resultName: 'Green', resultColor: '#22C55E' },
  { name1: 'Blue', color1: '#3B82F6', name2: 'Red', color2: '#EF4444', resultName: 'Purple', resultColor: '#A855F7' },
  { name1: 'Cyan', color1: '#06B6D4', name2: 'Magenta', color2: '#EC4899', resultName: 'Blue', resultColor: '#3B82F6' }
];

// Harmony angles
const harmonies = {
  complementary: [0, 180],
  analogous: [0, 30, 60],
  triadic: [0, 120, 240],
  split: [0, 150, 210]
};

// State
let currentEmotion = 0;
let currentMix = 0;
let currentHarmony = 'complementary';
let wheelHue = 0;
let mixProgress = 0;
let isMixing = false;

// DOM Elements
const loadingScreen = document.getElementById('loading');
const navDock = document.getElementById('navDock');
const progressRail = document.getElementById('progressRail');

// Initialize
window.addEventListener('DOMContentLoaded', () => {
  initLoading();
  initHeroCanvas();
  initColorWheel();
  initBasics();
  initPsychology();
  initDesign();
  initMixing();
  initNavigation();
  initScrollSpy();
});

// Loading Screen
function initLoading() {
  setTimeout(() => {
    loadingScreen.classList.add('hidden');
  }, 1500);
}

// Hero Canvas Animation
function initHeroCanvas() {
  const canvas = document.getElementById('heroCanvas');
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  let particles = [];
  let animationId;
  
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  
  resize();
  window.addEventListener('resize', resize);
  
  // Create particles
  for (let i = 0; i < 15; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      radius: Math.random() * 150 + 50,
      hue: Math.random() * 360
    });
  }
  
  function animate() {
    ctx.fillStyle = 'rgba(15, 23, 42, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.hue += 0.2;
      
      // Wrap around
      if (p.x < -p.radius) p.x = canvas.width + p.radius;
      if (p.x > canvas.width + p.radius) p.x = -p.radius;
      if (p.y < -p.radius) p.y = canvas.height + p.radius;
      if (p.y > canvas.height + p.radius) p.y = -p.radius;
      
      const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.radius);
      gradient.addColorStop(0, `hsla(${p.hue}, 70%, 60%, 0.3)`);
      gradient.addColorStop(0.5, `hsla(${p.hue}, 70%, 50%, 0.1)`);
      gradient.addColorStop(1, 'transparent');
      
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();
    });
    
    animationId = requestAnimationFrame(animate);
  }
  
  animate();
}

// Color Wheel
function initColorWheel() {
  const canvas = document.getElementById('wheelCanvas');
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;
  const radius = Math.min(centerX, centerY) - 20;
  
  // Draw color wheel
  function drawWheel() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    for (let angle = 0; angle < 360; angle++) {
      const startAngle = (angle - 90) * Math.PI / 180;
      const endAngle = (angle - 89) * Math.PI / 180;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = `hsl(${angle}, 80%, 50%)`;
      ctx.fill();
    }
    
    // Draw harmony indicators
    const harmonyAngles = harmonies[currentHarmony];
    harmonyAngles.forEach(offset => {
      const angle = (wheelHue + offset) % 360;
      const rad = (angle - 90) * Math.PI / 180;
      const x = centerX + Math.cos(rad) * (radius + 15);
      const y = centerY + Math.sin(rad) * (radius + 15);
      
      ctx.beginPath();
      ctx.arc(x, y, 10, 0, Math.PI * 2);
      ctx.fillStyle = `hsl(${angle}, 80%, 50%)`;
      ctx.fill();
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 2;
      ctx.stroke();
    });
  }
  
  drawWheel();
  
  // Click to select color
  canvas.addEventListener('click', (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left - centerX;
    const y = e.clientY - rect.top - centerY;
    
    let angle = Math.atan2(y, x) * 180 / Math.PI + 90;
    if (angle < 0) angle += 360;
    
    wheelHue = Math.round(angle);
    drawWheel();
    updatePalette();
  });
  
  // Harmony buttons
  document.querySelectorAll('.harmony-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.harmony-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentHarmony = btn.dataset.harmony;
      drawWheel();
      updatePalette();
    });
  });
  
  function updatePalette() {
    const paletteContainer = document.getElementById('paletteColors');
    const harmonyAngles = harmonies[currentHarmony];
    
    paletteContainer.innerHTML = harmonyAngles.map(offset => {
      const angle = (wheelHue + offset) % 360;
      return `
        <div class="palette-color" style="background: hsl(${angle}, 80%, 50%);">
          <code>HSL(${angle}, 80%, 50%)</code>
        </div>
      `;
    }).join('');
  }
}

// Basics Section - Background glow
function initBasics() {
  const glow = document.getElementById('basicsGlow');
  const cards = document.querySelectorAll('.color-card');
  
  cards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      const color = card.dataset.color;
      glow.style.background = `radial-gradient(circle at 50% 50%, ${color}15 0%, transparent 70%)`;
    });
    
    card.addEventListener('mouseleave', () => {
      glow.style.background = 'transparent';
    });
  });
}

// Psychology Section
function initPsychology() {
  const emotionBtns = document.querySelectorAll('.emotion-btn');
  
  emotionBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const index = parseInt(btn.dataset.emotion);
      setEmotion(index);
      
      emotionBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
}

function setEmotion(index) {
  const emotion = emotions[index];
  currentEmotion = index;
  
  // Update circle
  const circle = document.getElementById('emotionCircle');
  circle.style.background = emotion.color;
  circle.style.boxShadow = `0 0 80px ${emotion.color}40`;
  circle.innerHTML = `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${emotion.icon}</svg>`;
  
  // Update name
  document.getElementById('emotionName').style.color = emotion.color;
  document.getElementById('emotionName').textContent = emotion.name;
  
  // Update description
  document.getElementById('emotionDesc').textContent = emotion.description;
  
  // Update tags
  const tagsContainer = document.getElementById('emotionTags');
  tagsContainer.innerHTML = emotion.emotions.map(e => 
    `<span style="background: ${emotion.color}30; color: ${emotion.color};">${e}</span>`
  ).join('');
  
  // Update uses
  const usesContainer = document.getElementById('emotionUses');
  usesContainer.innerHTML = emotion.uses.map(u => 
    `<li style="--dot-color: ${emotion.color};">${u}</li>`
  ).join('');
  
  // Update background glow
  const glow = document.getElementById('psychGlow');
  glow.style.background = `radial-gradient(ellipse at 50% 50%, ${emotion.color}10 0%, transparent 70%)`;
}

// Design Section - Comparison Slider
function initDesign() {
  const slider = document.getElementById('comparisonSlider');
  const badDesign = document.getElementById('badDesign');
  const handle = document.getElementById('sliderHandle');
  
  let isDragging = false;
  
  function updateSlider(x) {
    const rect = slider.getBoundingClientRect();
    let percentage = ((x - rect.left) / rect.width) * 100;
    percentage = Math.max(0, Math.min(100, percentage));
    
    badDesign.style.clipPath = `inset(0 ${100 - percentage}% 0 0)`;
    handle.style.left = `${percentage}%`;
  }
  
  handle.addEventListener('mousedown', () => isDragging = true);
  document.addEventListener('mouseup', () => isDragging = false);
  document.addEventListener('mousemove', (e) => {
    if (isDragging) updateSlider(e.clientX);
  });
  
  // Touch support
  handle.addEventListener('touchstart', () => isDragging = true);
  document.addEventListener('touchend', () => isDragging = false);
  document.addEventListener('touchmove', (e) => {
    if (isDragging) updateSlider(e.touches[0].clientX);
  });
}

// Mixing Lab Section
function initMixing() {
  const mixBtns = document.querySelectorAll('.mix-btn');
  const mixBtn = document.getElementById('mixBtn');
  const resetBtn = document.getElementById('resetBtn');
  
  // Mix selection
  mixBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      mixBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentMix = parseInt(btn.dataset.mix);
      resetMix();
      updateMixDisplay();
    });
  });
  
  // Mix button
  mixBtn.addEventListener('click', () => {
    if (isMixing || mixProgress >= 100) return;
    isMixing = true;
    animateMix();
  });
  
  // Reset button
  resetBtn.addEventListener('click', resetMix);
  
  updateMixDisplay();
}

function updateMixDisplay() {
  const mix = colorMixes[currentMix];
  
  document.getElementById('name1').textContent = mix.name1;
  document.getElementById('code1').textContent = mix.color1;
  document.getElementById('liquid1').style.background = mix.color1;
  
  document.getElementById('name2').textContent = mix.name2;
  document.getElementById('code2').textContent = mix.color2;
  document.getElementById('liquid2').style.background = mix.color2;
  
  document.getElementById('resultName').textContent = mix.resultName;
  document.getElementById('resultName').style.color = mix.resultColor;
  document.getElementById('resultCode').textContent = mix.resultColor;
  document.getElementById('resultLiquid').style.background = 
    `linear-gradient(to top, ${mix.resultColor}, ${mix.color1}40)`;
  document.getElementById('progressFill').style.background = 
    `linear-gradient(to right, ${mix.color1}, ${mix.resultColor})`;
}

function animateMix() {
  if (!isMixing) return;
  
  mixProgress += 1;
  
  const mix = colorMixes[currentMix];
  
  // Update liquid heights
  document.getElementById('liquid1').style.height = `${100 - mixProgress * 0.5}%`;
  document.getElementById('liquid2').style.height = `${100 - mixProgress * 0.5}%`;
  document.getElementById('resultLiquid').style.height = `${mixProgress}%`;
  
  // Update progress
  document.getElementById('progressFill').style.width = `${mixProgress}%`;
  document.getElementById('progressText').textContent = `${mixProgress}%`;
  
  if (mixProgress < 100) {
    requestAnimationFrame(animateMix);
  } else {
    isMixing = false;
  }
}

function resetMix() {
  isMixing = false;
  mixProgress = 0;
  
  document.getElementById('liquid1').style.height = '100%';
  document.getElementById('liquid2').style.height = '100%';
  document.getElementById('resultLiquid').style.height = '0%';
  document.getElementById('progressFill').style.width = '0%';
  document.getElementById('progressText').textContent = '0%';
}

// Navigation
function initNavigation() {
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    const heroHeight = window.innerHeight;
    
    if (scrollY > heroHeight * 0.5) {
      navDock.classList.add('visible');
      progressRail.classList.add('visible');
    } else {
      navDock.classList.remove('visible');
      progressRail.classList.remove('visible');
    }
  });
}

// Scroll Spy
function initScrollSpy() {
  const sections = ['basics', 'wheel', 'psychology', 'design', 'mixing'];
  const navItems = document.querySelectorAll('.nav-item');
  const progressDots = document.querySelectorAll('.progress-dot');
  
  window.addEventListener('scroll', () => {
    const scrollPosition = window.scrollY + window.innerHeight / 3;
    
    sections.forEach((section, index) => {
      const element = document.getElementById(section);
      if (!element) return;
      
      const offsetTop = element.offsetTop;
      const offsetHeight = element.offsetHeight;
      
      if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
        navItems.forEach(item => item.classList.remove('active'));
        progressDots.forEach(dot => dot.classList.remove('active'));
        
        if (navItems[index]) navItems[index].classList.add('active');
        if (progressDots[index]) progressDots[index].classList.add('active');
      }
    });
  });
}

// Intersection Observer for animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('animate-in');
    }
  });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.color-group, .harmony-panel, .emotion-display, .mixing-lab, .resource-card').forEach(el => {
  observer.observe(el);
});
