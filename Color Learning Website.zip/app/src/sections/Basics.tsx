import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ColorInfo {
  name: string;
  hex: string;
  description: string;
}

const primaryColors: ColorInfo[] = [
  { name: 'Red', hex: '#EF4444', description: 'The color of passion and energy' },
  { name: 'Yellow', hex: '#EAB308', description: 'The color of joy and optimism' },
  { name: 'Blue', hex: '#3B82F6', description: 'The color of calm and trust' },
];

const secondaryColors: ColorInfo[] = [
  { name: 'Orange', hex: '#F97316', description: 'Red + Yellow = Enthusiasm' },
  { name: 'Green', hex: '#22C55E', description: 'Yellow + Blue = Growth' },
  { name: 'Purple', hex: '#A855F7', description: 'Red + Blue = Luxury' },
];

const tertiaryColors: ColorInfo[] = [
  { name: 'Red-Orange', hex: '#FB7185', description: 'Vermilion warmth' },
  { name: 'Yellow-Orange', hex: '#FBBF24', description: 'Amber golden' },
  { name: 'Yellow-Green', hex: '#84CC16', description: 'Chartreuse fresh' },
  { name: 'Blue-Green', hex: '#06B6D4', description: 'Teal tranquil' },
  { name: 'Blue-Purple', hex: '#6366F1', description: 'Indigo deep' },
  { name: 'Red-Purple', hex: '#EC4899', description: 'Magenta bold' },
];

const Basics = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const primaryRef = useRef<HTMLDivElement>(null);
  const secondaryRef = useRef<HTMLDivElement>(null);
  const tertiaryRef = useRef<HTMLDivElement>(null);
  const [activeColor, setActiveColor] = useState<string | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const triggers: ScrollTrigger[] = [];

    // Heading animation
    const headingTrigger = ScrollTrigger.create({
      trigger: headingRef.current,
      start: 'top 80%',
      onEnter: () => {
        gsap.fromTo(
          headingRef.current,
          { opacity: 0, y: 50 },
          { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }
        );
      },
      once: true,
    });
    triggers.push(headingTrigger);

    // Primary colors animation
    const primaryTrigger = ScrollTrigger.create({
      trigger: primaryRef.current,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          primaryRef.current?.querySelectorAll('.color-card'),
          { opacity: 0, y: 40, scale: 0.9 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.15,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });
    triggers.push(primaryTrigger);

    // Secondary colors animation
    const secondaryTrigger = ScrollTrigger.create({
      trigger: secondaryRef.current,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          secondaryRef.current?.querySelectorAll('.color-card'),
          { opacity: 0, y: 40, scale: 0.9 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.15,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });
    triggers.push(secondaryTrigger);

    // Tertiary colors animation
    const tertiaryTrigger = ScrollTrigger.create({
      trigger: tertiaryRef.current,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          tertiaryRef.current?.querySelectorAll('.color-card'),
          { opacity: 0, y: 40, scale: 0.9 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });
    triggers.push(tertiaryTrigger);

    return () => {
      triggers.forEach((trigger) => trigger.kill());
    };
  }, []);

  const ColorCard = ({ color, index }: { color: ColorInfo; index: number }) => (
    <div
      className="color-card group relative overflow-hidden rounded-2xl cursor-pointer transition-all duration-500"
      style={{ animationDelay: `${index * 0.1}s` }}
      onMouseEnter={() => setActiveColor(color.hex)}
      onMouseLeave={() => setActiveColor(null)}
    >
      <div
        className="h-32 sm:h-40 w-full transition-all duration-500 group-hover:scale-110"
        style={{ backgroundColor: color.hex }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
        <h4 className="font-display font-bold text-white text-lg">{color.name}</h4>
        <p className="text-white/80 text-sm">{color.description}</p>
        <p className="text-white/60 text-xs font-mono mt-1">{color.hex}</p>
      </div>
    </div>
  );

  return (
    <section
      id="basics"
      ref={sectionRef}
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8"
    >
      {/* Background glow */}
      <div
        className="absolute inset-0 transition-colors duration-700 pointer-events-none"
        style={{
          background: activeColor
            ? `radial-gradient(circle at 50% 50%, ${activeColor}10 0%, transparent 70%)`
            : 'transparent',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section header */}
        <div ref={headingRef} className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Foundation
          </span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            The <span className="gradient-text">Genesis</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Before the masterpiece, comes the foundation. Understand the primary building
            blocks of every hue you&apos;ve ever seen.
          </p>
        </div>

        {/* Primary Colors */}
        <div ref={primaryRef} className="mb-16">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 via-yellow-500 to-blue-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">1</span>
            </div>
            <div>
              <h3 className="font-display text-2xl font-bold">Primary Colors</h3>
              <p className="text-muted-foreground">The three colors that cannot be mixed</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {primaryColors.map((color, index) => (
              <ColorCard key={color.name} color={color} index={index} />
            ))}
          </div>
        </div>

        {/* Secondary Colors */}
        <div ref={secondaryRef} className="mb-16">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 via-green-500 to-purple-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">2</span>
            </div>
            <div>
              <h3 className="font-display text-2xl font-bold">Secondary Colors</h3>
              <p className="text-muted-foreground">Created by mixing two primary colors</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {secondaryColors.map((color, index) => (
              <ColorCard key={color.name} color={color} index={index} />
            ))}
          </div>
        </div>

        {/* Tertiary Colors */}
        <div ref={tertiaryRef}>
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-400 via-cyan-400 to-amber-400 flex items-center justify-center">
              <span className="text-white font-bold text-lg">3</span>
            </div>
            <div>
              <h3 className="font-display text-2xl font-bold">Tertiary Colors</h3>
              <p className="text-muted-foreground">Made by mixing primary and secondary colors</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {tertiaryColors.map((color, index) => (
              <ColorCard key={color.name} color={color} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Basics;
