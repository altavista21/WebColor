import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Heart, Zap, Cloud, Flame, Leaf, Crown, Brain, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface EmotionData {
  color: string;
  name: string;
  emotions: string[];
  icon: React.ReactNode;
  description: string;
  uses: string[];
}

const emotions: EmotionData[] = [
  {
    color: '#EF4444',
    name: 'Red',
    emotions: ['Passion', 'Energy', 'Urgency', 'Love', 'Anger'],
    icon: <Heart className="w-8 h-8" />,
    description: 'The most emotionally intense color. Red stimulates a faster heartbeat and breathing.',
    uses: ['Call-to-action buttons', 'Sale promotions', 'Food branding', 'Warning signs'],
  },
  {
    color: '#3B82F6',
    name: 'Blue',
    emotions: ['Trust', 'Calm', 'Stability', 'Sadness', 'Professionalism'],
    icon: <Cloud className="w-8 h-8" />,
    description: 'The color of the sky and sea. Blue causes the body to produce calming chemicals.',
    uses: ['Corporate branding', 'Healthcare', 'Technology', 'Financial services'],
  },
  {
    color: '#EAB308',
    name: 'Yellow',
    emotions: ['Joy', 'Optimism', 'Energy', 'Caution', 'Warmth'],
    icon: <Sparkles className="w-8 h-8" />,
    description: 'The color of sunshine. Yellow produces a warming effect and stimulates mental activity.',
    uses: ['Children\'s products', 'Creative industries', 'Warning labels', 'Food packaging'],
  },
  {
    color: '#22C55E',
    name: 'Green',
    emotions: ['Growth', 'Harmony', 'Freshness', 'Safety', 'Envy'],
    icon: <Leaf className="w-8 h-8" />,
    description: 'The color of nature. Green is the easiest color on the eyes and has healing power.',
    uses: ['Environmental causes', 'Organic products', 'Health & wellness', 'Financial growth'],
  },
  {
    color: '#A855F7',
    name: 'Purple',
    emotions: ['Luxury', 'Creativity', 'Mystery', 'Royalty', 'Spirituality'],
    icon: <Crown className="w-8 h-8" />,
    description: 'Combines the stability of blue and the energy of red. Associated with royalty and luxury.',
    uses: ['Beauty products', 'Premium brands', 'Creative services', 'Spiritual content'],
  },
  {
    color: '#F97316',
    name: 'Orange',
    emotions: ['Enthusiasm', 'Creativity', 'Warmth', 'Success', 'Encouragement'],
    icon: <Flame className="w-8 h-8" />,
    description: 'Combines the energy of red and the happiness of yellow. Represents enthusiasm and fascination.',
    uses: ['Sports brands', 'Call-to-actions', 'Youth marketing', 'Food & beverage'],
  },
  {
    color: '#06B6D4',
    name: 'Cyan',
    emotions: ['Clarity', 'Refreshment', 'Youth', 'Technology', 'Cleanliness'],
    icon: <Zap className="w-8 h-8" />,
    description: 'A refreshing color that evokes feelings of cleanliness and modern technology.',
    uses: ['Tech startups', 'Clean products', 'Water-related brands', 'Modern design'],
  },
  {
    color: '#EC4899',
    name: 'Pink',
    emotions: ['Romance', 'Compassion', 'Playfulness', 'Femininity', 'Sweetness'],
    icon: <Brain className="w-8 h-8" />,
    description: 'A calming color that represents compassion and nurturing. Associated with love and kindness.',
    uses: ['Beauty & fashion', 'Charitable causes', 'Baby products', 'Romantic themes'],
  },
];

const Psychology = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [bgColor, setBgColor] = useState(emotions[0].color);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 60%',
      onEnter: () => {
        gsap.fromTo(
          section.querySelectorAll('.emotion-card'),
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.08,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  // Update background color when active emotion changes
  useEffect(() => {
    setBgColor(emotions[activeIndex].color);
  }, [activeIndex]);

  return (
    <section
      id="psychology"
      ref={sectionRef}
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      {/* Animated background */}
      <div
        className="absolute inset-0 transition-colors duration-1000 ease-out"
        style={{
          background: `radial-gradient(ellipse at 50% 50%, ${bgColor}15 0%, transparent 70%)`,
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full bg-pink-500/10 text-pink-400 text-sm font-medium mb-4">
            Emotional Impact
          </span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Color <span className="gradient-text">Speaks</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Red isn&apos;t just red. It&apos;s anger, passion, and urgency. Explore the
            subconscious language of light.
          </p>
        </div>

        {/* Active emotion display */}
        <div className="mb-12">
          <div className="glass rounded-3xl p-8 sm:p-12 transition-all duration-500">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              {/* Left: Color visualization */}
              <div className="flex flex-col items-center">
                <div
                  className="w-48 h-48 sm:w-64 sm:h-64 rounded-full shadow-2xl transition-all duration-500 flex items-center justify-center"
                  style={{
                    backgroundColor: emotions[activeIndex].color,
                    boxShadow: `0 0 80px ${emotions[activeIndex].color}60`,
                  }}
                >
                  <div className="text-white/90">{emotions[activeIndex].icon}</div>
                </div>
                <h3
                  className="font-display text-3xl sm:text-4xl font-bold mt-6 transition-colors duration-500"
                  style={{ color: emotions[activeIndex].color }}
                >
                  {emotions[activeIndex].name}
                </h3>
              </div>

              {/* Right: Emotion details */}
              <div>
                <p className="text-lg text-foreground/90 mb-6">
                  {emotions[activeIndex].description}
                </p>

                {/* Emotion tags */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                    Associated Emotions
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {emotions[activeIndex].emotions.map((emotion) => (
                      <span
                        key={emotion}
                        className="px-3 py-1 rounded-full text-sm font-medium"
                        style={{
                          backgroundColor: `${emotions[activeIndex].color}20`,
                          color: emotions[activeIndex].color,
                        }}
                      >
                        {emotion}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Common uses */}
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                    Common Uses
                  </h4>
                  <ul className="space-y-2">
                    {emotions[activeIndex].uses.map((use) => (
                      <li key={use} className="flex items-center gap-2 text-foreground/80">
                        <div
                          className="w-1.5 h-1.5 rounded-full"
                          style={{ backgroundColor: emotions[activeIndex].color }}
                        />
                        {use}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Emotion selector grid */}
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
          {emotions.map((emotion, index) => (
            <button
              key={emotion.name}
              onClick={() => setActiveIndex(index)}
              className={`emotion-card aspect-square rounded-xl transition-all duration-300 flex flex-col items-center justify-center gap-2 ${
                activeIndex === index
                  ? 'ring-2 ring-white scale-110'
                  : 'hover:scale-105 opacity-60 hover:opacity-100'
              }`}
              style={{ backgroundColor: `${emotion.color}30` }}
            >
              <div
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center"
                style={{ backgroundColor: emotion.color }}
              >
                <div className="text-white/90 scale-75">{emotion.icon}</div>
              </div>
              <span className="text-xs font-medium hidden sm:block" style={{ color: emotion.color }}>
                {emotion.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Psychology;
