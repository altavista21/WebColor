import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BookOpen, ExternalLink, Palette, GraduationCap, Lightbulb, ArrowUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Resource {
  title: string;
  author: string;
  description: string;
  type: 'book' | 'tool' | 'course';
  link: string;
}

const resources: Resource[] = [
  {
    title: 'Interaction of Color',
    author: 'Josef Albers',
    description: 'The definitive book on color theory, exploring how colors interact and influence each other.',
    type: 'book',
    link: '#',
  },
  {
    title: 'Color Hunt',
    author: 'Online Tool',
    description: 'A curated collection of beautiful color palettes for designers and artists.',
    type: 'tool',
    link: 'https://colorhunt.co',
  },
  {
    title: 'Adobe Color',
    author: 'Adobe',
    description: 'Create, browse, and share color combinations with this powerful online tool.',
    type: 'tool',
    link: 'https://color.adobe.com',
  },
  {
    title: 'The Elements of Color',
    author: 'Johannes Itten',
    description: 'A comprehensive treatise on the color wheel and color relationships.',
    type: 'book',
    link: '#',
  },
  {
    title: 'Color Theory for Designers',
    author: 'Smashing Magazine',
    description: 'A complete guide to understanding and applying color in digital design.',
    type: 'course',
    link: '#',
  },
  {
    title: 'Coolors',
    author: 'Online Tool',
    description: 'Generate perfect color palettes in seconds with this intuitive tool.',
    type: 'tool',
    link: 'https://coolors.co',
  },
];

const Resources = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 70%',
      onEnter: () => {
        gsap.fromTo(
          section.querySelectorAll('.resource-card'),
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  const getIcon = (type: string) => {
    switch (type) {
      case 'book':
        return <BookOpen className="w-5 h-5" />;
      case 'tool':
        return <Palette className="w-5 h-5" />;
      case 'course':
        return <GraduationCap className="w-5 h-5" />;
      default:
        return <Lightbulb className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'book':
        return 'bg-amber-500/20 text-amber-400';
      case 'tool':
        return 'bg-cyan-500/20 text-cyan-400';
      case 'course':
        return 'bg-green-500/20 text-green-400';
      default:
        return 'bg-primary/20 text-primary';
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section
      id="resources"
      ref={sectionRef}
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full bg-amber-500/10 text-amber-400 text-sm font-medium mb-4">
            Learn More
          </span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            The <span className="gradient-text">Library</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Deepen your understanding with these curated resources on color theory and design.
          </p>
        </div>

        {/* Resources Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {resources.map((resource, index) => (
            <a
              key={index}
              href={resource.link}
              target="_blank"
              rel="noopener noreferrer"
              className="resource-card glass rounded-2xl p-6 hover:bg-white/5 transition-all duration-300 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-xl ${getTypeColor(resource.type)}`}>
                  {getIcon(resource.type)}
                </div>
                <ExternalLink className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <span className={`inline-block px-2 py-1 rounded text-xs font-medium mb-3 ${getTypeColor(resource.type)}`}>
                {resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}
              </span>
              <h4 className="font-display font-bold text-lg mb-1 group-hover:text-primary transition-colors">
                {resource.title}
              </h4>
              <p className="text-sm text-muted-foreground mb-3">{resource.author}</p>
              <p className="text-sm text-foreground/70">{resource.description}</p>
            </a>
          ))}
        </div>

        {/* Featured Book */}
        <div className="glass rounded-3xl p-8 sm:p-12 mb-20">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <span className="inline-block px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 text-sm font-medium mb-4">
                Featured Resource
              </span>
              <h3 className="font-display text-3xl sm:text-4xl font-bold mb-4">
                Interaction of Color
              </h3>
              <p className="text-lg text-muted-foreground mb-4">
                By Josef Albers
              </p>
              <p className="text-foreground/80 mb-6">
                Originally published in 1963, this influential book presents Albers&apos; unique approach 
                to color theory. Through a series of exercises and studies, it demonstrates how colors 
                interact with and influence each other, challenging conventional wisdom about color 
                relationships.
              </p>
              <div className="flex flex-wrap gap-2 mb-6">
                {['Color Theory', 'Design Classic', 'Essential Reading'].map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 rounded-full text-sm bg-white/10 text-foreground/70"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <a
                href="#"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary text-white font-semibold hover:opacity-90 transition-opacity"
              >
                <BookOpen className="w-5 h-5" />
                Learn More
              </a>
            </div>
            <div className="relative">
              <img
                src="/img_book_1.jpg"
                alt="Interaction of Color book cover"
                className="rounded-2xl shadow-2xl w-full max-w-sm mx-auto"
              />
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-primary/20 rounded-full blur-2xl" />
              <div className="absolute -top-4 -left-4 w-32 h-32 bg-secondary/20 rounded-full blur-2xl" />
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="border-t border-white/10 pt-12">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="text-center sm:text-left">
              <h3 className="font-display text-2xl font-bold gradient-text mb-2">
                ColorLearn
              </h3>
              <p className="text-sm text-muted-foreground">
                Master the art and science of color.
              </p>
            </div>

            <div className="flex items-center gap-6">
              <a href="#basics" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Basics
              </a>
              <a href="#wheel" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Color Wheel
              </a>
              <a href="#psychology" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Psychology
              </a>
              <a href="#mixing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Mixing Lab
              </a>
            </div>

            <button
              onClick={scrollToTop}
              className="p-3 rounded-full glass hover:bg-white/10 transition-all duration-300 hover:scale-110 group"
              aria-label="Back to top"
            >
              <ArrowUp className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </button>
          </div>

          <div className="mt-8 pt-8 border-t border-white/5 text-center">
            <p className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} ColorLearn. Built for color enthusiasts everywhere.
            </p>
          </div>
        </footer>
      </div>
    </section>
  );
};

export default Resources;
