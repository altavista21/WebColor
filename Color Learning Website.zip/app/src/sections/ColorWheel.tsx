import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Info, RotateCcw } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

type HarmonyType = 'complementary' | 'analogous' | 'triadic' | 'split-complementary' | 'tetradic';

interface HarmonyInfo {
  type: HarmonyType;
  name: string;
  description: string;
  angles: number[];
}

const harmonies: HarmonyInfo[] = [
  {
    type: 'complementary',
    name: 'Complementary',
    description: 'Colors opposite each other on the wheel. High contrast, vibrant look.',
    angles: [0, 180],
  },
  {
    type: 'analogous',
    name: 'Analogous',
    description: 'Colors next to each other. Harmonious, serene, comfortable.',
    angles: [0, 30, 60],
  },
  {
    type: 'triadic',
    name: 'Triadic',
    description: 'Three colors evenly spaced. Bold, balanced, colorful.',
    angles: [0, 120, 240],
  },
  {
    type: 'split-complementary',
    name: 'Split Complementary',
    description: 'Base color plus two adjacent to its complement. Strong visual contrast, less tension.',
    angles: [0, 150, 210],
  },
  {
    type: 'tetradic',
    name: 'Tetradic (Double Split)',
    description: 'Four colors in two complementary pairs. Rich, complex, requires balance.',
    angles: [0, 90, 180, 270],
  },
];

const ColorWheel = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const wheelRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState(0);
  const [selectedHarmony, setSelectedHarmony] = useState<HarmonyType>('complementary');
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef(0);
  const rotationStartRef = useRef(0);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 60%',
      onEnter: () => {
        gsap.fromTo(
          section.querySelectorAll('.wheel-element'),
          { opacity: 0, scale: 0.8 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  // Generate wheel segments
  const segments = 24;
  const segmentAngle = 360 / segments;

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartRef.current = e.clientX;
    rotationStartRef.current = rotation;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const delta = (e.clientX - dragStartRef.current) * 0.5;
    setRotation(rotationStartRef.current + delta);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const getHarmonyColors = () => {
    const harmony = harmonies.find((h) => h.type === selectedHarmony);
    if (!harmony) return [];
    return harmony.angles.map((angle) => (angle + rotation) % 360);
  };

  const harmonyColors = getHarmonyColors();

  return (
    <section
      id="wheel"
      ref={sectionRef}
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16 wheel-element">
          <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
            Color Relationships
          </span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Find Your <span className="gradient-text">Harmony</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Color isn&apos;t just seen; it&apos;s felt. Discover the relationships that create
            balance, tension, and emotion.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Interactive Color Wheel */}
          <div
            ref={wheelRef}
            className="relative aspect-square max-w-lg mx-auto wheel-element"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            {/* Wheel container */}
            <div
              className="absolute inset-0 rounded-full cursor-grab active:cursor-grabbing transition-shadow duration-300"
              style={{
                transform: `rotate(${rotation}deg)`,
                boxShadow: isDragging ? '0 0 60px rgba(99, 102, 241, 0.4)' : 'none',
              }}
            >
              {/* Color segments */}
              {Array.from({ length: segments }).map((_, i) => {
                const hue = i * segmentAngle;
                const isInHarmony = harmonyColors.some(
                  (angle) => Math.abs(angle - hue) < segmentAngle / 2 ||
                    Math.abs(angle - hue) > 360 - segmentAngle / 2
                );
                return (
                  <div
                    key={i}
                    className="absolute top-1/2 left-1/2 origin-bottom wheel-segment"
                    style={{
                      width: '4px',
                      height: '50%',
                      backgroundColor: `hsl(${hue}, 80%, 50%)`,
                      transform: `translateX(-50%) rotate(${hue}deg)`,
                      opacity: isInHarmony ? 1 : 0.4,
                      transformOrigin: '50% 0%',
                    }}
                  />
                );
              })}

              {/* Inner circle with gradient */}
              <div
                className="absolute inset-8 rounded-full"
                style={{
                  background: `conic-gradient(from 0deg, ${Array.from(
                    { length: 360 },
                    (_, i) => `hsl(${i}, 80%, 50%)`
                  ).join(', ')})`,
                }}
              />

              {/* Center indicator */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-4 h-4 rounded-full bg-white shadow-lg" />
              </div>
            </div>

            {/* Harmony indicator dots */}
            {harmonyColors.map((angle, i) => (
              <div
                key={i}
                className="absolute w-6 h-6 rounded-full border-2 border-white shadow-lg pointer-events-none transition-all duration-300"
                style={{
                  backgroundColor: `hsl(${angle}, 80%, 50%)`,
                  top: `${50 - 42 * Math.cos((angle - rotation) * Math.PI / 180)}%`,
                  left: `${50 + 42 * Math.sin((angle - rotation) * Math.PI / 180)}%`,
                  transform: 'translate(-50%, -50%)',
                }}
              />
            ))}

            {/* Drag hint */}
            <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-sm text-muted-foreground flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              Drag to rotate
            </div>
          </div>

          {/* Harmony Selection */}
          <div className="space-y-4 wheel-element">
            <div className="flex items-center gap-2 mb-6">
              <Info className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">
                Select a harmony type to see color relationships
              </span>
            </div>

            {harmonies.map((harmony) => (
              <button
                key={harmony.type}
                onClick={() => setSelectedHarmony(harmony.type)}
                className={`w-full text-left p-5 rounded-2xl transition-all duration-300 harmony-card ${
                  selectedHarmony === harmony.type
                    ? 'active glass'
                    : 'hover:bg-white/5'
                }`}
              >
                <div className="flex items-start gap-4">
                  {/* Color preview */}
                  <div className="flex -space-x-2">
                    {harmony.angles.map((angle, i) => (
                      <div
                        key={i}
                        className="w-8 h-8 rounded-full border-2 border-background"
                        style={{
                          backgroundColor: `hsl(${(angle + rotation) % 360}, 80%, 50%)`,
                        }}
                      />
                    ))}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-display font-bold text-lg mb-1">
                      {harmony.name}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {harmony.description}
                    </p>
                  </div>
                </div>
              </button>
            ))}

            {/* Current harmony colors */}
            <div className="mt-8 p-6 rounded-2xl glass">
              <h5 className="font-display font-bold mb-4">Current Palette</h5>
              <div className="flex gap-4">
                {harmonyColors.map((angle, i) => (
                  <div key={i} className="flex-1">
                    <div
                      className="h-20 rounded-xl mb-2"
                      style={{
                        backgroundColor: `hsl(${angle}, 80%, 50%)`,
                      }}
                    />
                    <p className="text-xs text-center text-muted-foreground font-mono">
                      HSL({Math.round(angle)}, 80%, 50%)
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ColorWheel;
