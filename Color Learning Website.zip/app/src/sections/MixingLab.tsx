import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Beaker, RefreshCw, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

gsap.registerPlugin(ScrollTrigger);

interface ColorMix {
  name1: string;
  color1: string;
  name2: string;
  color2: string;
  resultName: string;
  resultColor: string;
}

const colorMixes: ColorMix[] = [
  {
    name1: 'Red',
    color1: '#EF4444',
    name2: 'Yellow',
    color2: '#EAB308',
    resultName: 'Orange',
    resultColor: '#F97316',
  },
  {
    name1: 'Yellow',
    color1: '#EAB308',
    name2: 'Blue',
    color2: '#3B82F6',
    resultName: 'Green',
    resultColor: '#22C55E',
  },
  {
    name1: 'Blue',
    color1: '#3B82F6',
    name2: 'Red',
    color2: '#EF4444',
    resultName: 'Purple',
    resultColor: '#A855F7',
  },
  {
    name1: 'Cyan',
    color1: '#06B6D4',
    name2: 'Magenta',
    color2: '#EC4899',
    resultName: 'Blue',
    resultColor: '#3B82F6',
  },
];

const MixingLab = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [selectedMix, setSelectedMix] = useState(0);
  const [mixProgress, setMixProgress] = useState(0);
  const [isMixing, setIsMixing] = useState(false);
  const beaker1Ref = useRef<HTMLDivElement>(null);
  const beaker2Ref = useRef<HTMLDivElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const currentMix = colorMixes[selectedMix];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 60%',
      onEnter: () => {
        gsap.fromTo(
          section.querySelectorAll('.lab-element'),
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  const handleMix = () => {
    if (isMixing) return;
    setIsMixing(true);
    setMixProgress(0);

    // Animate mixing
    gsap.to({}, {
      duration: 2,
      onUpdate: function() {
        setMixProgress(this.progress() * 100);
      },
      onComplete: () => {
        setIsMixing(false);
      },
    });
  };

  const handleReset = () => {
    setMixProgress(0);
    setIsMixing(false);
  };

  return (
    <section
      id="mixing"
      ref={sectionRef}
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16 lab-element">
          <span className="inline-block px-4 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-sm font-medium mb-4">
            Interactive Lab
          </span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            The <span className="gradient-text">Alchemist</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Mix. Match. Create. See how subtractive and additive color models work in
            real-time.
          </p>
        </div>

        {/* Mix Selection */}
        <div className="flex flex-wrap justify-center gap-3 mb-12 lab-element">
          {colorMixes.map((mix, index) => (
            <button
              key={index}
              onClick={() => {
                setSelectedMix(index);
                handleReset();
              }}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                selectedMix === index
                  ? 'bg-primary text-white'
                  : 'glass hover:bg-white/10'
              }`}
            >
              {mix.name1} + {mix.name2}
            </button>
          ))}
        </div>

        {/* Mixing Visualization */}
        <div className="glass rounded-3xl p-8 sm:p-12 lab-element">
          <div className="flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-12">
            {/* Beaker 1 */}
            <div ref={beaker1Ref} className="relative">
              <div className="w-32 h-40 sm:w-40 sm:h-48 relative">
                {/* Beaker outline */}
                <div className="absolute inset-0 border-2 border-white/30 rounded-b-3xl rounded-t-lg overflow-hidden backdrop-blur-sm">
                  {/* Liquid */}
                  <div
                    className="absolute bottom-0 left-0 right-0 transition-all duration-500"
                    style={{
                      height: `${100 - mixProgress * 0.5}%`,
                      backgroundColor: currentMix.color1,
                      opacity: 0.8,
                    }}
                  />
                </div>
                {/* Label */}
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-center">
                  <p className="font-display font-bold">{currentMix.name1}</p>
                  <p className="text-xs text-muted-foreground font-mono">{currentMix.color1}</p>
                </div>
              </div>
            </div>

            {/* Plus sign */}
            <div className="text-muted-foreground">
              <Plus className="w-8 h-8" />
            </div>

            {/* Beaker 2 */}
            <div ref={beaker2Ref} className="relative">
              <div className="w-32 h-40 sm:w-40 sm:h-48 relative">
                {/* Beaker outline */}
                <div className="absolute inset-0 border-2 border-white/30 rounded-b-3xl rounded-t-lg overflow-hidden backdrop-blur-sm">
                  {/* Liquid */}
                  <div
                    className="absolute bottom-0 left-0 right-0 transition-all duration-500"
                    style={{
                      height: `${100 - mixProgress * 0.5}%`,
                      backgroundColor: currentMix.color2,
                      opacity: 0.8,
                    }}
                  />
                </div>
                {/* Label */}
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-center">
                  <p className="font-display font-bold">{currentMix.name2}</p>
                  <p className="text-xs text-muted-foreground font-mono">{currentMix.color2}</p>
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="text-primary animate-pulse">
              <svg className="w-8 h-8 rotate-90 lg:rotate-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </div>

            {/* Result Beaker */}
            <div ref={resultRef} className="relative">
              <div className="w-40 h-48 sm:w-48 sm:h-56 relative">
                {/* Beaker outline */}
                <div className="absolute inset-0 border-2 border-white/30 rounded-b-3xl rounded-t-lg overflow-hidden backdrop-blur-sm">
                  {/* Mixed liquid */}
                  <div
                    className="absolute bottom-0 left-0 right-0 transition-all duration-300"
                    style={{
                      height: `${mixProgress}%`,
                      background: `linear-gradient(to top, ${currentMix.resultColor}, ${currentMix.color1}40)`,
                      opacity: 0.9,
                    }}
                  >
                    {/* Bubbles effect */}
                    {mixProgress > 0 && (
                      <div className="absolute inset-0 overflow-hidden">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <div
                            key={i}
                            className="absolute w-2 h-2 rounded-full bg-white/30 animate-float"
                            style={{
                              left: `${20 + i * 15}%`,
                              bottom: `${10 + (i % 3) * 20}%`,
                              animationDelay: `${i * 0.3}s`,
                            }}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                {/* Label */}
                <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 text-center">
                  <p className="font-display font-bold text-lg" style={{ color: currentMix.resultColor }}>
                    {currentMix.resultName}
                  </p>
                  <p className="text-xs text-muted-foreground font-mono">{currentMix.resultColor}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex justify-center gap-4 mt-16">
            <Button
              size="lg"
              onClick={handleMix}
              disabled={isMixing || mixProgress >= 100}
              className="px-8 py-6 text-lg font-semibold rounded-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all duration-300 disabled:opacity-50"
            >
              <Beaker className="mr-2 w-5 h-5" />
              {isMixing ? 'Mixing...' : mixProgress >= 100 ? 'Mixed!' : 'Mix Colors'}
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={handleReset}
              disabled={mixProgress === 0}
              className="px-8 py-6 text-lg font-semibold rounded-full glass hover:bg-white/10 transition-all duration-300 disabled:opacity-50"
            >
              <RefreshCw className="mr-2 w-5 h-5" />
              Reset
            </Button>
          </div>

          {/* Progress bar */}
          <div className="mt-8 max-w-md mx-auto">
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-100"
                style={{
                  width: `${mixProgress}%`,
                  background: `linear-gradient(to right, ${currentMix.color1}, ${currentMix.resultColor})`,
                }}
              />
            </div>
            <p className="text-center text-sm text-muted-foreground mt-2">
              Mix Progress: {Math.round(mixProgress)}%
            </p>
          </div>
        </div>

        {/* Color Model Info */}
        <div className="grid sm:grid-cols-2 gap-6 mt-12 lab-element">
          <div className="glass rounded-2xl p-6">
            <h4 className="font-display font-bold text-lg mb-3 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              Subtractive (RYB)
            </h4>
            <p className="text-sm text-muted-foreground mb-3">
              Used in painting and printing. Colors are created by absorbing (subtracting) light.
            </p>
            <ul className="text-sm space-y-1 text-foreground/80">
              <li>• Red + Yellow = Orange</li>
              <li>• Yellow + Blue = Green</li>
              <li>• Blue + Red = Purple</li>
            </ul>
          </div>

          <div className="glass rounded-2xl p-6">
            <h4 className="font-display font-bold text-lg mb-3 flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              Additive (RGB)
            </h4>
            <p className="text-sm text-muted-foreground mb-3">
              Used in screens and digital displays. Colors are created by adding light.
            </p>
            <ul className="text-sm space-y-1 text-foreground/80">
              <li>• Red + Green = Yellow</li>
              <li>• Green + Blue = Cyan</li>
              <li>• Blue + Red = Magenta</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MixingLab;
