import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MoveHorizontal, Check, X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Design = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 60%',
      onEnter: () => {
        gsap.fromTo(
          section.querySelectorAll('.design-element'),
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
          }
        );
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  const handleMouseDown = () => setIsDragging(true);
  const handleMouseUp = () => setIsDragging(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging || !sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = e.touches[0].clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const badDesignPoints = [
    'Clashing colors create visual tension',
    'Poor contrast makes text unreadable',
    'Too many colors confuse the viewer',
    'No visual hierarchy established',
  ];

  const goodDesignPoints = [
    'Harmonious palette creates balance',
    'High contrast ensures readability',
    'Limited colors maintain focus',
    'Clear visual hierarchy guides users',
  ];

  return (
    <section
      id="design"
      ref={sectionRef}
      className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16 design-element">
          <span className="inline-block px-4 py-1 rounded-full bg-green-500/10 text-green-400 text-sm font-medium mb-4">
            Practical Application
          </span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Context is <span className="gradient-text">King</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See how color choices make or break a design. Slide to reveal the impact of
            informed palette selection.
          </p>
        </div>

        {/* Comparison Slider */}
        <div
          ref={sliderRef}
          className="relative rounded-2xl overflow-hidden shadow-2xl design-element cursor-ew-resize select-none"
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onMouseMove={handleMouseMove}
          onTouchMove={handleTouchMove}
          onTouchStart={handleMouseDown}
          onTouchEnd={handleMouseUp}
        >
          {/* Good Design (Background) */}
          <div className="relative aspect-video">
            <img
              src="/img_design_good.jpg"
              alt="Good design example"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            
            {/* Good design label */}
            <div className="absolute top-4 right-4 px-4 py-2 rounded-full bg-green-500/90 text-white text-sm font-semibold flex items-center gap-2">
              <Check className="w-4 h-4" />
              Good Design
            </div>

            {/* Good design points */}
            <div className="absolute bottom-4 right-4 left-1/2 text-right space-y-2">
              {goodDesignPoints.map((point, i) => (
                <div
                  key={i}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-500/80 text-white text-sm"
                  style={{ opacity: sliderPosition > 50 ? (sliderPosition - 50) / 50 : 0 }}
                >
                  <Check className="w-3 h-3" />
                  {point}
                </div>
              ))}
            </div>
          </div>

          {/* Bad Design (Foreground - clipped) */}
          <div
            className="absolute inset-0 overflow-hidden"
            style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
          >
            <img
              src="/img_design_bad.jpg"
              alt="Bad design example"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            
            {/* Bad design label */}
            <div className="absolute top-4 left-4 px-4 py-2 rounded-full bg-red-500/90 text-white text-sm font-semibold flex items-center gap-2">
              <X className="w-4 h-4" />
              Bad Design
            </div>

            {/* Bad design points */}
            <div className="absolute bottom-4 left-4 right-1/2 space-y-2">
              {badDesignPoints.map((point, i) => (
                <div
                  key={i}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-red-500/80 text-white text-sm"
                  style={{ opacity: sliderPosition < 50 ? (50 - sliderPosition) / 50 : 0 }}
                >
                  <X className="w-3 h-3" />
                  {point}
                </div>
              ))}
            </div>
          </div>

          {/* Slider Handle */}
          <div
            className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize shadow-lg"
            style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
          >
            <div
              className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center transition-transform ${
                isDragging ? 'scale-110' : ''
              }`}
            >
              <MoveHorizontal className="w-6 h-6 text-slate-900" />
            </div>
          </div>
        </div>

        {/* Design Tips */}
        <div className="grid sm:grid-cols-3 gap-6 mt-12 design-element">
          <div className="glass rounded-2xl p-6">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center mb-4">
              <span className="text-2xl font-bold text-primary">60</span>
            </div>
            <h4 className="font-display font-bold text-lg mb-2">60-30-10 Rule</h4>
            <p className="text-sm text-muted-foreground">
              Use 60% dominant color, 30% secondary, and 10% accent for balanced designs.
            </p>
          </div>

          <div className="glass rounded-2xl p-6">
            <div className="w-12 h-12 rounded-xl bg-secondary/20 flex items-center justify-center mb-4">
              <span className="text-2xl font-bold text-secondary">4.5</span>
            </div>
            <h4 className="font-display font-bold text-lg mb-2">Contrast Ratio</h4>
            <p className="text-sm text-muted-foreground">
              Maintain at least 4.5:1 contrast ratio for text readability and accessibility.
            </p>
          </div>

          <div className="glass rounded-2xl p-6">
            <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center mb-4">
              <span className="text-2xl font-bold text-green-500">3</span>
            </div>
            <h4 className="font-display font-bold text-lg mb-2">Color Limit</h4>
            <p className="text-sm text-muted-foreground">
              Stick to 2-3 main colors. Too many colors create confusion and visual noise.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Design;
